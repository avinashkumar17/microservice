package com.example.demo.controller;

import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dao.DaoImpl;
import com.example.demo.entity.Products;
import com.example.demo.entity.PurchaseDetails;

@RestController
public class Controller {

@Autowired
DaoImpl dao;
@Autowired 
RestTemplate template;

HttpHeaders headers = new HttpHeaders();

@RequestMapping(value="/purchaseDetails",method=RequestMethod.GET)
public ResponseEntity<List<PurchaseDetails>> getproductList() {
	return new ResponseEntity<List<PurchaseDetails>>(dao.getProductList(),null,HttpStatus.OK);
}


@CrossOrigin
@RequestMapping(value="/createPurchase",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<String> createPurchase(@RequestBody String valueObject) throws JSONException{  
	JSONObject object=new JSONObject(valueObject);	
	if(dao.createPurchase(1,Integer.parseInt(object.getString("productId"))))
	{	
		int i=(int) dao.getLastUpdatedPurchaseId();
		//object.append("purchaseId",i);
		object.put("purchaseId",i);
		System.out.println("inside if"+object.toString()+" and i :"+i);
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(object.toString(),headers);
		String data=template.postForObject("http://shipping-service/rest/shippingCreate",entity,String.class);
		System.out.println("the create order details :"+data);
		if(data.equals("success"))
		{
			return new ResponseEntity<String>("success",null,HttpStatus.OK);	
		}else
		{
			return new ResponseEntity<String>("success",null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}else {
	return new ResponseEntity<String>("failure",null,HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

	
}

