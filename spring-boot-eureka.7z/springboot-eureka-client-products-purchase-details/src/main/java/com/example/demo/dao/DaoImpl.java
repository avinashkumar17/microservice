package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Products;
import com.example.demo.entity.PurchaseDetails;

@Repository
public class DaoImpl {

@Autowired
ProductRepo repo;


	public List<PurchaseDetails> getProductList() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	
	public boolean createPurchase(int purchase,int productId ) {
		// TODO Auto-generated method stub
		System.out.print("the createPurchase datas :"+purchase+" and "+productId);
		try {
		
		repo.createPurchase(purchase, productId);
		return true;
		}catch(Exception ex)
		{
			System.out.println("the exception of createPurchase e:"+ex.getLocalizedMessage());
			return false;
		}
	}


	public long getLastUpdatedPurchaseId() {
		// TODO Auto-generated method stub
		return repo.getLastPurchaseId().longValue();
	}

}
