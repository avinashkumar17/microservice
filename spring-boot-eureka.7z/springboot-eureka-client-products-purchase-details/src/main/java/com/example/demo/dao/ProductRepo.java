package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Products;
import com.example.demo.entity.PurchaseDetails;
import java.sql.Timestamp;
import java.util.List;



import java.lang.String;
import java.math.BigInteger;


public interface ProductRepo  extends JpaRepository<PurchaseDetails, Long>{
    
	
	@Query("select e from Products e left join fetch e.purchaseDetails details")
	public List<Products> fetchPurchaseDetails();

	@Transactional	
    @Modifying
	@Query(nativeQuery=true,value="INSERT INTO product_purchase_details(IS_PURCHASE,PRODUCT_ID) values (?1,?2)")	
	public void createPurchase(int purchase,int productId);
	
	@Query(nativeQuery=true,value="SELECT LAST_INSERT_ID()")
	public BigInteger getLastPurchaseId();
	

}
