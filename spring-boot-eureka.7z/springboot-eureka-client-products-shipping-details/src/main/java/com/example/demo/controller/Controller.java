package com.example.demo.controller;

import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.DaoImpl;
import com.example.demo.entity.Products;
import com.example.demo.entity.PurchaseDetails;

@RestController
public class Controller {

@Autowired
DaoImpl dao;

@RequestMapping(value="/shippingCreate",method=RequestMethod.POST)
public ResponseEntity<String> createShippingDetails(@RequestBody String jsonObject) throws JSONException {
	JSONObject obj=new JSONObject(jsonObject);
	if(dao.createShippingDetails(obj.getString("deliveryAddress"),Integer.parseInt(obj.getString("purchaseId"))))
	{
		return new ResponseEntity<String>("success",null,HttpStatus.OK);	
	}else
	{
		return new ResponseEntity<String>("failure",null,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}
	
}

