package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Products;
import com.example.demo.entity.PurchaseDetails;

@Repository
public class DaoImpl {

@Autowired
ProductRepo repo;

public boolean createShippingDetails(String address,int purchaseId) {
	// TODO Auto-generated method stub
	try {
	repo.createShippingDetails(address,purchaseId);
	return true;
	}catch(Exception e)
	{
		return false;
	}
}


	

}
