package com.example.demo.entity;

import javax.persistence.*;
import com.example.demo.entity.PurchaseDetails;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name="PRODUCTS")
public class Products {
	


@Id
@Column(name="PRODUCT_ID")
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int productId;

@Column(name="PRODUCT_NAME")
private String productName;

@Column(name="PRICE")
private String price;

@OneToOne(mappedBy="products",cascade =  CascadeType.ALL,fetch = FetchType.LAZY)
@JsonIgnore
private PurchaseDetails purchaseDetails;

public int getProductId() {
	return productId;
}

public void setProductId(int productId) {
	this.productId = productId;
}

public String getProductName() {
	return productName;
}

public void setProductName(String productName) {
	this.productName = productName;
}

public String getPrice() {
	return price;
}

public void setPrice(String price) {
	this.price = price;
}

public PurchaseDetails getPurchaseDetails() {
	return purchaseDetails;
}

public void setPurchaseDetails(PurchaseDetails purchaseDetails) {
	this.purchaseDetails = purchaseDetails;
}



}
