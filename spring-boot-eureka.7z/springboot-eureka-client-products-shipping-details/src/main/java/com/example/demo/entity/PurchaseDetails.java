package com.example.demo.entity;

import java.sql.Timestamp;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "product_purchase_details")
public class PurchaseDetails {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int purchaseId;

	@Column(name = "IS_PURCHASE")
	private int isPurchase;

	@Column(name = "PURCHASE_DATE")
	private Timestamp purchaseDate;

	@OneToOne(fetch = FetchType.EAGER,cascade =  CascadeType.ALL)
	@JoinColumn(name = "PRODUCT_ID", referencedColumnName = "PRODUCT_ID")
	public Products products;

	public Products getProducts() {
		return products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public int getIsPurchase() {
		return isPurchase;
	}

	public void setIsPurchase(int isPurchase) {
		this.isPurchase = isPurchase;
	}

	public Timestamp getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Timestamp purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

}
