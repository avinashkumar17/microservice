package com.example.demo.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "shipping_details")
public class ShippingDetails {
	
@Id
@Column(name="id")
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int shippingId;

@Column(name="shipping_address")
private String shippingAddress;

@OneToOne(cascade=CascadeType.ALL)
@JoinColumn(name="purchase_id",referencedColumnName="id")
private PurchaseDetails purchaseDetails;

public int getShippingId() {
	return shippingId;
}

public void setShippingId(int shippingId) {
	this.shippingId = shippingId;
}

public String getShippingAddress() {
	return shippingAddress;
}

public void setShippingAddress(String shippingAddress) {
	this.shippingAddress = shippingAddress;
}

public PurchaseDetails getPurchaseDetails() {
	return purchaseDetails;
}

public void setPurchaseDetails(PurchaseDetails purchaseDetails) {
	this.purchaseDetails = purchaseDetails;
}



}
