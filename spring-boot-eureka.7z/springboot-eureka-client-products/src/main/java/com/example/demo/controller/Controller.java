package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dao.DaoImpl;
import com.example.demo.entity.Products;
import com.example.demo.entity.ProductsDTO;

@RestController
public class Controller {

@Autowired
DaoImpl dao;

@Autowired 
RestTemplate template;

@CrossOrigin
@RequestMapping(value="/products",method=RequestMethod.GET)
public ResponseEntity<List<Products>> getproductList() {
	return new ResponseEntity<List<Products>>(dao.getProductList(),null,HttpStatus.OK);
}

@CrossOrigin
@RequestMapping(value="/uniqueProductDetails",method=RequestMethod.GET)
public ResponseEntity<Products> getproduct(@RequestParam(value="productId") String id) {
	System.out.println("the details :"+id);
	return new ResponseEntity<Products>(dao.getProduct(Integer.parseInt(id)),null,HttpStatus.OK);
}

@CrossOrigin
@RequestMapping(value="/createOrder",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<String>createOrder(@RequestBody String requestObject){	
	HttpHeaders headers = new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	HttpEntity<String> entity = new HttpEntity<String>(requestObject,headers);
	String data=template.postForObject("http://purchase-service/rest/createPurchase",entity,String.class);
	System.out.println("the create order details :"+data);
	if(data.equals("success"))
	{
		return new ResponseEntity<String>("success",null,HttpStatus.OK);	
	}else
	{
		return new ResponseEntity<String>("failure",null,HttpStatus.OK);
	}
	
}



}

