package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Products;
import com.example.demo.entity.ProductsDTO;

@Repository
public class DaoImpl {

@Autowired
ProductRepo repo;




	public List<Products> getProductList() {
		// TODO Auto-generated method stub
		return repo.fetchPurchaseDetails();
	}


	public Products getProduct(int id) {
		
		return repo.findByProductId(id);
		// TODO Auto-generated method stub
		
	}


	

}
