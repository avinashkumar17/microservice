package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Products;
import com.example.demo.entity.ProductsDTO;
import com.example.demo.entity.PurchaseDetails;


public interface ProductRepo  extends JpaRepository<Products, Long>{
	
     public Products findByProductId(int purchasedetails);
     
     
	@Query("select e from Products e left join e.purchaseDetails details")
	public List<Products> fetchPurchaseDetails();
	//new com.example.demo.entity.ProductsDTO(e.productId,e.productName,e.price)

    
	
	
}
