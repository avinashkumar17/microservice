
public class Sample {

	
public static void main(String[] arg]) {
	System.out.println("the word");
}
}
